// screens/login-screen.tsx
// CampusHub — Premium Login Screen
// Cinematic AMOLED hero + glass card form

import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router } from 'expo-router';
import { Eye, EyeOff, GraduationCap, Lock, Mail, Sparkles } from 'lucide-react-native';
import React, { useCallback, useState } from 'react';
import {
  KeyboardAvoidingView, Platform, Pressable, StyleSheet,
  Text, TextInput, View,
} from 'react-native';
import Animated, {
  FadeIn, FadeInDown, FadeInUp, ZoomIn,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Radius, Spacing, Typography } from '@/constants/theme';
import { useTheme } from '@/context/ThemeContext';
import { Badge, PrimaryButton, SpringButton } from '@/components/ui';
import { useAuthStore } from '@/store/auth.store';

export function LoginScreen() {
  const { theme, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  const login = useAuthStore((s) => s.login);

  const handleLogin = useCallback(() => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      login({
        id: '1',
        name: 'Arjun Singh',
        email: email || 'arjun@campus.edu',
        enrollmentNo: '21CS0042',
        branch: 'Computer Science Engg.',
        semester: 6,
        avatarInitials: 'AS',
      });
      router.replace('/(tabs)' as any);
    }, 1200);
  }, [email, login]);

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.void }}>
      {/* ── Background gradient ── */}
      <LinearGradient
        colors={isDark ? ['#0A0620', '#000000'] : ['#EEF2FF', '#F2F2F7']}
        style={StyleSheet.absoluteFillObject}
      />

      {/* Radial glow */}
      <View style={{
        position: 'absolute',
        top: -60, left: '50%', marginLeft: -120,
        width: 240, height: 240, borderRadius: 120,
        backgroundColor: theme.colors.primaryGlow,
      }} />

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}>
        <View style={{
          flex: 1,
          paddingHorizontal: Spacing.page.horizontal,
          paddingTop: insets.top + 40,
          justifyContent: 'center',
        }}>
          {/* ── Brand ── */}
          <Animated.View entering={FadeInDown.duration(600)} style={{ alignItems: 'center', marginBottom: 48 }}>
            <Animated.View
              entering={ZoomIn.duration(500).delay(100)}
              style={{
                width: 88, height: 88, borderRadius: 28,
                backgroundColor: theme.colors.primaryMuted,
                borderWidth: 1.5,
                borderColor: `${theme.colors.primaryLight}40`,
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: 20,
              }}>
              <GraduationCap color={theme.colors.primaryLight} size={44} />
            </Animated.View>

            <Text style={[Typography.display.small, { color: theme.colors.textPrimary }]}>
              CampusHub
            </Text>
            <Text style={[Typography.body.md, { color: theme.colors.textSecondary, marginTop: 6 }]}>
              Your university, supercharged.
            </Text>
            <Badge label="✦ Student Portal" color={theme.colors.primary} size="md" />
          </Animated.View>

          {/* ── Form Card ── */}
          <Animated.View entering={FadeInUp.duration(600).delay(200)}>
            <View style={{
              backgroundColor: theme.colors.surface,
              borderRadius: Radius.xxl,
              padding: Spacing.xxl,
              borderWidth: 1,
              borderColor: theme.colors.border,
            }}>
              <Text style={[Typography.headline.lg, { color: theme.colors.textPrimary, marginBottom: Spacing.xl }]}>
                Welcome back
              </Text>

              {/* Email */}
              <View style={{ marginBottom: Spacing.lg }}>
                <Text style={[Typography.label.lg, { color: theme.colors.textSecondary, marginBottom: 8 }]}>
                  Email / Roll No.
                </Text>
                <View style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: theme.colors.void,
                  borderRadius: Radius.md,
                  borderWidth: 1,
                  borderColor: theme.colors.borderStrong,
                  paddingHorizontal: 14,
                  height: 52,
                  gap: 10,
                }}>
                  <Mail color={theme.colors.textTertiary} size={18} />
                  <TextInput
                    value={email}
                    onChangeText={setEmail}
                    placeholder="you@campus.edu"
                    placeholderTextColor={theme.colors.textTertiary}
                    keyboardType="email-address"
                    autoCapitalize="none"
                    style={[Typography.body.md, { flex: 1, color: theme.colors.textPrimary }]}
                  />
                </View>
              </View>

              {/* Password */}
              <View style={{ marginBottom: Spacing.xxl }}>
                <Text style={[Typography.label.lg, { color: theme.colors.textSecondary, marginBottom: 8 }]}>
                  Password
                </Text>
                <View style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: theme.colors.void,
                  borderRadius: Radius.md,
                  borderWidth: 1,
                  borderColor: theme.colors.borderStrong,
                  paddingHorizontal: 14,
                  height: 52,
                  gap: 10,
                }}>
                  <Lock color={theme.colors.textTertiary} size={18} />
                  <TextInput
                    value={password}
                    onChangeText={setPassword}
                    placeholder="••••••••"
                    placeholderTextColor={theme.colors.textTertiary}
                    secureTextEntry={!showPass}
                    style={[Typography.body.md, { flex: 1, color: theme.colors.textPrimary }]}
                  />
                  <Pressable onPress={() => setShowPass(!showPass)}>
                    {showPass
                      ? <EyeOff color={theme.colors.textTertiary} size={18} />
                      : <Eye color={theme.colors.textTertiary} size={18} />
                    }
                  </Pressable>
                </View>
              </View>

              {/* Login button */}
              <PrimaryButton
                label={loading ? 'Signing in…' : 'Sign In'}
                onPress={handleLogin}
                fullWidth
                size="lg"
                disabled={loading}
              />

              {/* Forgot password */}
              <Pressable style={{ alignItems: 'center', marginTop: Spacing.xl }}>
                <Text style={[Typography.body.sm, { color: theme.colors.primary }]}>
                  Forgot password?
                </Text>
              </Pressable>
            </View>
          </Animated.View>

          {/* Footer */}
          <Animated.View entering={FadeIn.duration(400).delay(500)} style={{ alignItems: 'center', marginTop: Spacing.xxl }}>
            <Text style={[Typography.caption, { color: theme.colors.textTertiary, textAlign: 'center' }]}>
              By signing in, you agree to the{' '}
              <Text style={{ color: theme.colors.primary }}>Terms of Use</Text>
              {' '}and{' '}
              <Text style={{ color: theme.colors.primary }}>Privacy Policy</Text>.
            </Text>
          </Animated.View>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}
