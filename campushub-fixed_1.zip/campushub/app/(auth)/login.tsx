// app/(auth)/login.tsx
import { LoginScreen } from '@/screens/login-screen';
export default LoginScreen;
