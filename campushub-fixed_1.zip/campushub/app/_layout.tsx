// app/_layout.tsx  — Root Layout (FIXED)
// Fixes:
//   1. Removed `import '@/global.css'` (NativeWind not used, file doesn't exist)
//   2. Added `import 'react-native-gesture-handler'` at top (required by reanimated)
//   3. ThemeProvider wraps everything; AppShell uses useTheme inside it
//   4. Stack screens match actual route files

import 'react-native-gesture-handler';

import {
  DarkTheme as NavDark,
  LightTheme as NavLight,
  ThemeProvider as NavThemeProvider,
} from '@react-navigation/native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

import { ThemeProvider, useTheme } from '@/context/ThemeContext';
import { AppProviders } from '@/providers/app-providers';

// Inner component — consumes ThemeContext (must be inside ThemeProvider)
function AppShell() {
  const { theme, isDark } = useTheme();

  const navTheme = isDark
    ? {
        ...NavDark,
        colors: {
          ...NavDark.colors,
          primary: theme.colors.primary,
          background: theme.colors.void,
          card: theme.colors.surface,
          text: theme.colors.textPrimary,
          border: theme.colors.border,
          notification: theme.colors.danger,
        },
      }
    : {
        ...NavLight,
        colors: {
          ...NavLight.colors,
          primary: theme.colors.primary,
          background: theme.colors.void,
          card: theme.colors.surface,
          text: theme.colors.textPrimary,
          border: theme.colors.border,
          notification: theme.colors.danger,
        },
      };

  return (
    <NavThemeProvider value={navTheme}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <Stack
        screenOptions={{
          headerShown: false,
          animation: 'fade',
          contentStyle: { backgroundColor: theme.colors.void },
        }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="(auth)" />
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="about" options={{ animation: 'slide_from_right' }} />
        <Stack.Screen name="attendance" options={{ animation: 'slide_from_bottom' }} />
      </Stack>
    </NavThemeProvider>
  );
}

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <ThemeProvider>
        <AppProviders>
          <AppShell />
        </AppProviders>
      </ThemeProvider>
    </GestureHandlerRootView>
  );
}
